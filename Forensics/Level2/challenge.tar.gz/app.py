#!/usr/bin/env python2
# -*- coding: utf8 -*-
from Secret import Secret

def patience():
    patience = Secret()
    
    print "-=-=[ Createur de code d'acces]=-=-"
    print " Pour rejoindre notre sect..groupe! vous devez faire preuve de patience."
    print " La patience est une vertu."
    print " Une vertue qui s'acquiert avec de la patience."
    
    print "\n    ________\n   /         \\\n   |          \\\n   |           \\\n   |            \\"
    print "   \        __\/_\\\n    \       \_/\_/\___\n     \/  / |  \ | \   \\\n    _/ _/ _|  | \  \  |_"
    print "   /  |  / /  / /  |  \ \_\n   | /  /  | |  \   \  \  \\\n\n"
    
    print "\n [*] Nous preparons votre code d'acces..."
    print patience.get_code()
 
if __name__ == '__main__':
    patience()
